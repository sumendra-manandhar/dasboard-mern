import { useTheme } from "@emotion/react";
import Contact from "components/public/Contact";
import Cta from "components/public/Cta";
import Footer from "components/public/Footer";
import Hero from "components/public/Hero";
import Insight from "components/public/Insight";
import Partners from "components/public/Partners";
import Testimonial from "components/public/Testimonial";
import Try from "components/public/Try";
import Whole from "components/public/Whole";
// import Whole from "components/public/whole";
import React from "react";

const Dashboard = () => {
  return (
    <>
      <Try />
      {/* <Hero /> */}

      <Insight />
      <Partners />

      <Testimonial />
      <Cta />
      {/* <Contact /> */}
      {/* <Footer /> */}
    </>
  );
};

export default Dashboard;
