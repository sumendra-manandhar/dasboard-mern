import Contact from "components/public/Contact";
import Hero from "components/public/Hero";
import React from "react";

const index = () => {
  return (
    <div>
      <Hero />
      <Contact />
    </div>
  );
};

export default index;
