// import React from "react";

// const Contact = () => {
//   return (
//     <>
//       {/* <!-- Section: Design Block --> */}
//       <section class="mb-32 text-gray-800 text-center bg-white">
//         {/* <style>
//       .map-container {
//         height: 700px;
//         z-index: -1;
//       }
//     </style>  */}
//         <div class="px-6 py-12 md:px-12 ">
//           <div class="container mx-auto xl:px-32">
//             <div class="grid lg:grid-cols-2  items-center ">
//               <div class="md:mt-12 lg:mt-0 mb-12 lg:mb-0">
//                 <div
//                   class="block rounded-lg shadow-lg px-6 py-12 md:px-12 lg:-mr-14"
//                   // style="background: hsla(0, 0%, 100%, 0.55); backdrop-filter: blur(30px)"
//                 >
//                   <h2 class="text-3xl font-bold mb-12">Contact us</h2>
//                   <form>
//                     <div class="form-group mb-6">
//                       <input
//                         type="text"
//                         class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
//                         id="exampleInput7"
//                         placeholder="Name"
//                       />
//                     </div>
//                     <div class="form-group mb-6">
//                       <input
//                         type="email"
//                         class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
//                         id="exampleInput8"
//                         placeholder="Email address"
//                       />
//                     </div>
//                     <div class="form-group mb-6">
//                       <textarea
//                         class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
//                         id="exampleFormControlTextarea13"
//                         rows="3"
//                         placeholder="Message"
//                       ></textarea>
//                     </div>
//                     <div class="form-group form-check text-center mb-6">
//                       <input
//                         type="checkbox"
//                         class="form-check-input appearance-none h-4 w-4 border border-gray-300 rounded-sm bg-white checked:bg-blue-600 checked:border-blue-600 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain mr-2 cursor-pointer"
//                         id="exampleCheck87"
//                         checked
//                       />
//                       <label
//                         class="form-check-label inline-block text-gray-800"
//                         for="exampleCheck87"
//                       >
//                         Send me a copy of this message
//                       </label>
//                     </div>
//                     <button
//                       type="submit"
//                       class="w-full px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out"
//                     >
//                       Send
//                     </button>
//                   </form>
//                 </div>
//               </div>
//               <div class="md:mb-12 lg:mb-0 h-96">
//                 <h1>This is map section</h1>
//                 {/* <div class="map-container relative shadow-lg rounded-lg"> */}
//                 <iframe
//                   title="map"
//                   src="https://maps.google.com/maps?q=lazimpat&t=&z=13&ie=UTF8&iwloc=&output=embed"
//                   class="left-0 top-0 w-full  h-full  rounded-lg"
//                   frameborder="0"
//                   allowfullscreen
//                 ></iframe>
//                 {/* </div> */}
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>
//     </>
//   );
// };

// export default Contact;

import React from "react";

const Contact = () => {
  return (
    <div>
      <section class='py-10 bg-gray-900 sm:py-16 lg:py-24'>
        <div class='max-w-6xl px-4 mx-auto sm:px-6 lg:px-8'>
          {" "}
          <div class='grid grid-cols-1 md:items-stretch md:grid-cols-2 gap-x-12 lg:gap-x-20 gap-y-10'>
            <div class='flex flex-col justify-between lg:py-5'>
              <div>
                <h2 class='text-3xl font-bold leading-tight text-white sm:text-4xl lg:leading-tight lg:text-5xl'>
                  It’s time to build something exciting!
                </h2>
                <p class='max-w-xl mx-auto mt-4 text-base leading-relaxed text-white'>
                  Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                  amet sint. Velit officia consequat duis.
                </p>

                <img
                  class='relative z-10 max-w-xs mx-auto -mb-16 md:hidden'
                  src='https://cdn.rareblocks.xyz/collection/celebration/images/contact/4/curve-line-mobile.svg'
                  alt=''
                />

                <img
                  class='hidden w-full translate-x-24 translate-y-8 md:block'
                  src='https://cdn.rareblocks.xyz/collection/celebration/images/contact/4/curve-line.svg'
                  alt=''
                />
              </div>

              <div class='hidden md:mt-auto md:block'>
                <div class='flex items-center'>
                  <svg
                    class='w-6 h-6 text-yellow-400'
                    xmlns='http://www.w3.org/2000/svg'
                    viewBox='0 0 20 20'
                    fill='currentColor'
                  >
                    <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                  </svg>
                  <svg
                    class='w-6 h-6 text-yellow-400'
                    xmlns='http://www.w3.org/2000/svg'
                    viewBox='0 0 20 20'
                    fill='currentColor'
                  >
                    <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                  </svg>
                  <svg
                    class='w-6 h-6 text-yellow-400'
                    xmlns='http://www.w3.org/2000/svg'
                    viewBox='0 0 20 20'
                    fill='currentColor'
                  >
                    <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                  </svg>
                  <svg
                    class='w-6 h-6 text-yellow-400'
                    xmlns='http://www.w3.org/2000/svg'
                    viewBox='0 0 20 20'
                    fill='currentColor'
                  >
                    <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                  </svg>
                  <svg
                    class='w-6 h-6 text-yellow-400'
                    xmlns='http://www.w3.org/2000/svg'
                    viewBox='0 0 20 20'
                    fill='currentColor'
                  >
                    <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                  </svg>
                </div>

                <blockquote class='mt-6'>
                  <p class='text-lg leading-relaxed text-white'>
                    You made it so simple. My new site is so much faster and
                    easier to work with than my old site. I just choose the
                    page, make the change and click save.
                  </p>
                </blockquote>

                <div class='flex items-center mt-8'>
                  <img
                    class='flex-shrink-0 object-cover w-10 h-10 rounded-full'
                    src='https://cdn.rareblocks.xyz/collection/celebration/images/contact/4/avatar.jpg'
                    alt=''
                  />
                  <div class='ml-4'>
                    <p class='text-base font-semibold text-white'>
                      Jenny Wilson
                    </p>
                    <p class='mt-px text-sm text-gray-400'>Product Designer</p>
                  </div>
                </div>
              </div>
            </div>

            <div class='lg:pl-12'>
              <div class='overflow-hidden bg-white rounded-md'>
                <div class='p-6 sm:p-10'>
                  <h3 class='text-3xl font-semibold text-black'>
                    Get a free quote
                  </h3>
                  <p class='mt-4 text-base text-gray-600'>
                    Amet minim mollit non deserunt ullamco est sit aliqua dolor
                    do amet sint.
                  </p>

                  <form action='#' method='POST' class='mt-4'>
                    <div class='space-y-6'>
                      <div>
                        <label
                          for=''
                          class='text-base font-medium text-gray-900'
                        >
                          {" "}
                          Your name{" "}
                        </label>
                        <div class='mt-2.5 relative'>
                          <input
                            type='text'
                            name=''
                            id=''
                            placeholder='Enter your full name'
                            class='block w-full px-4 py-4 text-black placeholder-gray-500 transition-all duration-200 bg-white border border-gray-200 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500 caret-orange-500'
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          for=''
                          class='text-base font-medium text-gray-900'
                        >
                          {" "}
                          Email address{" "}
                        </label>
                        <div class='mt-2.5 relative'>
                          <input
                            type='text'
                            name=''
                            id=''
                            placeholder='Enter your full name'
                            class='block w-full px-4 py-4 text-black placeholder-gray-500 transition-all duration-200 bg-white border border-gray-200 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500 caret-orange-500'
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          for=''
                          class='text-base font-medium text-gray-900'
                        >
                          {" "}
                          Project brief{" "}
                        </label>
                        <div class='mt-2.5 relative'>
                          <textarea
                            name=''
                            id=''
                            placeholder='Enter your project brief'
                            class='block w-full px-4 py-4 text-black placeholder-gray-500 transition-all duration-200 bg-white border border-gray-200 rounded-md resize-y focus:outline-none focus:ring-orange-500 focus:border-orange-500 caret-orange-500'
                            rows='4'
                          ></textarea>
                        </div>
                      </div>

                      <div>
                        <button
                          type='submit'
                          class='inline-flex items-center justify-center w-full px-4 py-4 text-base font-semibold text-white transition-all duration-200 bg-orange-500 border border-transparent rounded-md focus:outline-none hover:bg-orange-600 focus:bg-orange-600'
                        >
                          Get Free Quote
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <div class='md:hidden'>
              <div class='flex items-center'>
                <svg
                  class='w-6 h-6 text-yellow-400'
                  xmlns='http://www.w3.org/2000/svg'
                  viewBox='0 0 20 20'
                  fill='currentColor'
                >
                  <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                </svg>
                <svg
                  class='w-6 h-6 text-yellow-400'
                  xmlns='http://www.w3.org/2000/svg'
                  viewBox='0 0 20 20'
                  fill='currentColor'
                >
                  <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                </svg>
                <svg
                  class='w-6 h-6 text-yellow-400'
                  xmlns='http://www.w3.org/2000/svg'
                  viewBox='0 0 20 20'
                  fill='currentColor'
                >
                  <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                </svg>
                <svg
                  class='w-6 h-6 text-yellow-400'
                  xmlns='http://www.w3.org/2000/svg'
                  viewBox='0 0 20 20'
                  fill='currentColor'
                >
                  <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                </svg>
                <svg
                  class='w-6 h-6 text-yellow-400'
                  xmlns='http://www.w3.org/2000/svg'
                  viewBox='0 0 20 20'
                  fill='currentColor'
                >
                  <path d='M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z' />
                </svg>
              </div>

              <blockquote class='mt-6'>
                <p class='text-lg leading-relaxed text-white'>
                  You made it so simple. My new site is so much faster and
                  easier to work with than my old site. I just choose the page,
                  make the change and click save.
                </p>
              </blockquote>

              <div class='flex items-center mt-8'>
                <img
                  class='flex-shrink-0 object-cover w-10 h-10 rounded-full'
                  src='https://cdn.rareblocks.xyz/collection/celebration/images/contact/4/avatar.jpg'
                  alt=''
                />
                <div class='ml-4'>
                  <p class='text-base font-semibold text-white'>Jenny Wilson</p>
                  <p class='mt-px text-sm text-gray-400'>Product Designer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* secong part  */}
      <section class='py-10  sm:py-16 lg:py-20'>
        <div class='px-4 mx-auto sm:px-6 lg:px-8 max-w-7xl'>
          <div class='grid grid-cols-1 lg:grid-cols-3 gap-y-12 lg:gap-x-8 xl:gap-x-20'>
            <div>
              <h3 class='text-2xl font-semibold '>London Office</h3>
              <p class='mt-3 text-base text-gray-600'>
                Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                amet sint.
              </p>

              <div class='mt-10 space-y-5'>
                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z'
                    />
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M15 11a3 3 0 11-6 0 3 3 0 016 0z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    8502 Preston Rd. Inglewood, Maine 98380, USA{" "}
                  </span>
                </div>

                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    sales@example.com{" "}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h3 class='text-2xl font-semibold text-black'>New York Office</h3>
              <p class='mt-3 text-base text-gray-600'>
                Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                amet sint.
              </p>

              <div class='mt-10 space-y-5'>
                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z'
                    />
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M15 11a3 3 0 11-6 0 3 3 0 016 0z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    4517 Washington Ave. Manchester, Kentucky 39495{" "}
                  </span>
                </div>

                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    support@example.com{" "}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h3 class='text-2xl font-semibold text-black'>
                Singapore Office
              </h3>
              <p class='mt-3 text-base text-gray-600'>
                Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                amet sint.
              </p>

              <div class='mt-10 space-y-5'>
                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z'
                    />
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M15 11a3 3 0 11-6 0 3 3 0 016 0z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    3517 W. Gray St. Utica, Pennsylvania 57867{" "}
                  </span>
                </div>

                <div class='flex items-start'>
                  <svg
                    class='flex-shrink-0 text-blue-600 w-7 h-7'
                    xmlns='http://www.w3.org/2000/svg'
                    fill='none'
                    viewBox='0 0 24 24'
                    stroke='currentColor'
                  >
                    <path
                      stroke-linecap='round'
                      stroke-linejoin='round'
                      stroke-width='1.5'
                      d='M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'
                    />
                  </svg>
                  <span class='block ml-3 text-base font-medium text-gray-900'>
                    {" "}
                    contact@example.com{" "}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
