import React from "react";
import bgImage from "assets/bg.png";

const Try = () => {
  return (
    <div>
      <div>
        {/* <div class='bg-gradient-to-b from-green-50 to-green-100'> */}
        {/* <header class=''>
          <div class='px-4 mx-auto sm:px-6 lg:px-8'>
            <div class='flex items-center justify-between h-16 lg:h-20'>
              <div class='flex-shrink-0'>
                <a href='#' title='' class='flex'>
                  <img
                    class='w-auto h-8'
                    src='https://cdn.rareblocks.xyz/collection/celebration/images/hero/2/logo.svg'
                    alt=''
                  />
                </a>
              </div>

              <button
                type='button'
                class='inline-flex p-1     transition-all duration-200 border border-black lg:hidden focus:bg-gray-100 hover:bg-gray-100'
              >
                <svg
                  class='block w-6 h-6'
                  xmlns='http://www.w3.org/2000/svg'
                  fill='none'
                  viewBox='0 0 24 24'
                  stroke='currentColor'
                >
                  <path
                    stroke-linecap='round'
                    stroke-linejoin='round'
                    stroke-width='2'
                    d='M4 6h16M4 12h16M4 18h16'
                  />
                </svg>

                <svg
                  class='hidden w-6 h-6'
                  xmlns='http://www.w3.org/2000/svg'
                  fill='none'
                  viewBox='0 0 24 24'
                  stroke='currentColor'
                >
                  <path
                    stroke-linecap='round'
                    stroke-linejoin='round'
                    stroke-width='2'
                    d='M6 18L18 6M6 6l12 12'
                  ></path>
                </svg>
              </button>

              <div class='hidden ml-auto lg:flex lg:items-center lg:justify-center lg:space-x-10'>
                <a
                  href='#'
                  title=''
                  class='text-base font-semibold     transition-all duration-200 hover:text-opacity-80'
                >
                  {" "}
                  Features{" "}
                </a>

                <a
                  href='#'
                  title=''
                  class='text-base font-semibold     transition-all duration-200 hover:text-opacity-80'
                >
                  {" "}
                  Solutions{" "}
                </a>

                <a
                  href='#'
                  title=''
                  class='text-base font-semibold     transition-all duration-200 hover:text-opacity-80'
                >
                  {" "}
                  Resources{" "}
                </a>

                <a
                  href='#'
                  title=''
                  class='text-base font-semibold     transition-all duration-200 hover:text-opacity-80'
                >
                  {" "}
                  Pricing{" "}
                </a>

                <div class='w-px h-5 bg-black/20'></div>

                <a
                  href='#'
                  title=''
                  class='text-base font-semibold     transition-all duration-200 hover:text-opacity-80'
                >
                  {" "}
                  Log in{" "}
                </a>

                <a
                  href='#'
                  title=''
                  class='inline-flex items-center justify-center px-5 py-2.5 text-base font-semibold     border-2 border-black hover:bg-black hover:text-white transition-all duration-200 focus:bg-black focus:text-white'
                  role='button'
                >
                  {" "}
                  Try for free{" "}
                </a>
              </div>
            </div>
          </div>
        </header> */}

        <section class=' mt-12 py-10 sm:py-16 lg:py-24 '>
          <div class='px-4 mx-auto max-w-7xl sm:px-6 lg:px-8'>
            <div class='grid items-center grid-cols-1 gap-12 lg:grid-cols-2'>
              <div>
                <h1 class='text-4xl font-bold text-black sm:text-6xl xl:text-7xl'>
                  Better <br />
                  Intelligence
                </h1>
                <p class='mt-6 text-base text-black sm:text-xl'>
                  With our AI Powered market intelligence tools you can now
                  access to the credible market intelligence anytime at your
                  finger tips. You don’t need to be an insider anymore.
                </p>
                <a
                  href='#'
                  title=''
                  class='inline-flex items-center px-6 py-5 text-base font-semibold text-black transition-all duration-200 bg-green-300 mt-9 hover:bg-green-400 focus:bg-green-400'
                  role='button'
                >
                  {" "}
                  Get started for free{" "}
                </a>

                <div class='mt-8 border-t-2 border-black lg:mt-16 sm:mt-14'>
                  <div class='pt-8 sm:flex sm:items-center sm:justify-between sm:pt-8'>
                    <p class='text-base font-semibold text-black'>
                      App available on
                    </p>

                    <div class='flex items-center mt-5 space-x-5 sm:mt-0'>
                      {/* <a
                          href='#'
                          title=''
                          class='block transition-all duration-200 hover:opacity-80 focus:opacity-80'
                          role='button'
                        >
                          <img
                            class='w-auto rounded h-14 sm:h-16'
                            src='https://cdn.rareblocks.xyz/collection/celebration/images/hero/4/app-store-button.png'
                            alt=''
                          />
                        </a> */}

                      <a
                        href='#'
                        title=''
                        class='block transition-all duration-200 hover:opacity-80 focus:opacity-80'
                        role='button'
                      >
                        <img
                          class='w-auto rounded h-14 sm:h-16'
                          src='https://cdn.rareblocks.xyz/collection/celebration/images/hero/4/play-store-button.png'
                          alt=''
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <img
                  className=' h-[70vh]  float-right mr-16'
                  src={bgImage}
                  alt=''
                />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Try;
