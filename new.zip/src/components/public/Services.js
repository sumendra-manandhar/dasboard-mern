import React from "react";

const Services = () => {
  return (
    <div>
      <section class='py-10 bg-gray-100 sm:py-16 lg:py-24'>
        <div class='px-4 mx-auto sm:px-6 lg:px-8 max-w-7xl'>
          <div class='grid items-center grid-cols-1 gap-y-8 lg:grid-cols-2 gap-x-16 xl:gap-x-24'>
            <div class='relative mb-12'>
              <img
                class='w-full rounded-md'
                src='https://cdn.rareblocks.xyz/collection/celebration/images/content/1/team-work.jpg'
                alt=''
              />

              <div class='absolute w-full max-w-xs px-4 -translate-x-1/2 sm:px-0 sm:max-w-sm left-1/2 -bottom-12'>
                <div class='overflow-hidden bg-white rounded'>
                  <div class='px-10 py-6'>
                    <div class='flex items-center'>
                      <p class='flex-shrink-0 text-3xl font-bold text-blue-600 sm:text-4xl'>
                        37%
                      </p>
                      <p class='pl-6 text-sm font-medium text-black sm:text-lg'>
                        High Conversions <br />
                        on Landing Pages
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div class='flex items-center justify-center w-16 h-16 bg-white rounded-full'>
                <svg
                  class='w-8 h-8 text-orange-400'
                  xmlns='http://www.w3.org/2000/svg'
                  fill='none'
                  viewBox='0 0 24 24'
                  stroke='currentColor'
                >
                  <path
                    stroke-linecap='round'
                    stroke-linejoin='round'
                    stroke-width='1.5'
                    d='M13 10V3L4 14h7v7l9-11h-7z'
                  />
                </svg>
              </div>
              <h2 class='mt-10 text-3xl font-bold leading-tight text-black sm:text-4xl lg:text-5xl lg:leading-tight'>
                Build a perfect team within hours.
              </h2>
              <p class='mt-6 text-lg leading-relaxed text-gray-600'>
                Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                amet sint. Velit officia conse duis enim velit mollit.
                Exercitation veniam.
              </p>
              <a
                href='#'
                title=''
                class='inline-flex items-center justify-center px-10 py-4 text-base font-semibold text-white transition-all duration-200 rounded-md mt-9 bg-gradient-to-r from-fuchsia-600 to-blue-600 hover:opacity-80 focus:opacity-80'
                role='button'
              >
                {" "}
                Explore more{" "}
              </a>
            </div>
          </div>
        </div>
      </section>

      <section class='py-10 bg-gray-50 sm:py-16 lg:py-24'>
        <div class='max-w-6xl px-4 mx-auto sm:px-6 lg:px-8'>
          <div class='grid items-center grid-cols-1 lg:items-stretch md:grid-cols-2 gap-y-8 gap-x-12 xl:gap-x-20'>
            <div class='relative'>
              <div class='aspect-w-4 aspect-h-3'>
                <img
                  class='object-cover w-full h-full'
                  src='https://cdn.rareblocks.xyz/collection/celebration/images/testimonials/5/man-using-phone.jpg'
                  alt=''
                />
              </div>

              <div class='absolute inset-0 flex items-center justify-center'>
                <div class='flex items-center justify-center rounded-full w-28 h-28 bg-white/20'>
                  <button
                    type='button'
                    class='flex items-center justify-center w-20 h-20 text-white transition-all duration-200 rounded-full bg-gradient-to-r from-fuchsia-600 to-blue-600 hover:opacity-90'
                  >
                    <svg
                      class='w-6 h-6 lg:w-8 lg:h-8'
                      xmlns='http://www.w3.org/2000/svg'
                      viewBox='0 0 24 24'
                      fill='currentColor'
                    >
                      <path d='M8 6.82v10.36c0 .79.87 1.27 1.54.84l8.14-5.18c.62-.39.62-1.29 0-1.69L9.54 5.98C8.87 5.55 8 6.03 8 6.82z'></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>

            <div class='flex flex-col justify-between md:py-5'>
              <div class='lg:mt-auto'>
                <p class='text-xl font-semibold text-black'>
                  B. NAVYA: Stock and Portfolio (An AI based Portfolio Tracker)
                </p>
              </div>
              <blockquote>
                <p class='mt-6 text-l leading-relaxed text-black md:text-l'>
                  General investors face financial losses due to a lack of
                  market knowledge and insufficient time to react to market
                  events. With limited funds and high fees, they avoid seeking
                  professional advice and fall prey to market rumors and traps.
                  Even well-funded investors struggle to build portfolios
                  aligned with their goals and risk tolerance. AI-based
                  portfolio trackers provide accurate market insights,
                  personalized recommendations, and reduced manual tracking,
                  allowing investors to make informed decisions, avoid
                  investment mistakes, and achieve their financial goals at a
                  lower cost.
                </p>
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      <section class='py-10  sm:py-16 lg:py-24'>
        <div class='px-4 mx-auto sm:px-6 lg:px-8 max-w-7xl'>
          <div class='max-w-2xl mx-auto text-left sm:text-center'>
            <h2 class='text-3xl font-bold leading-tight  sm:text-4xl lg:text-5xl lg:leading-tight'>
              key features
            </h2>
            <p class='mt-4 text-xl '>
              Following are some of the key features that would make an
              investor’s life much easier
            </p>
          </div>

          <div class='grid grid-cols-1 gap-6 mt-8 sm:mt-12 xl:mt-20 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8 xl:gap-14'>
            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>1. Stock Overview</p>
                <p class='mt-1 text-gray-600 text-500'>
                  Stock Overview functionality provides users with a
                  comprehensive view of individual stocks. This includes
                  information such as price trends, financials, and key
                  performance indicators. By aggregating this information in one
                  place, the Stock Overview function helps users stay informed
                  and make informed investment decisions.
                </p>
              </div>
            </div>

            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>2. Watchlist</p>
                <p class='mt-1 text-gray-600 text-500'>
                  Watchlist functionality allows users to keep track of stocks
                  they are interested in by adding them to a personalized list.
                  This feature provides users with updates on the performance of
                  the stocks in their watchlist, enabling them to easily monitor
                  their potential investments.
                </p>
              </div>
            </div>

            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>3. Portfolio Summary</p>
                <p class='mt-1 text-gray-600 text-500'>
                  Portfolio Management functionality provides users with tools
                  to track their investment portfolio, manage their assets and
                  measure risk. This includes features such as adding and
                  removing stocks, viewing portfolio performance, and measuring
                  portfolio risk. By using the Portfolio Management function,
                  users can effectively monitor their investments, measure their
                  risk exposure, and make informed decisions to achieve their
                  financial goals.
                </p>
              </div>
            </div>

            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>4. Weekly AI Signals</p>
                <p class='mt-1 text-gray-600 text-500'>
                  The weekly AI generated buy/hold/sell signals feature uses
                  artificial intelligence algorithms to analyze market trends
                  and make recommendations on which stocks to buy, hold, or
                  sell. These signals are generated on a weekly basis and are
                  based on the latest market data. By using these signals, users
                  can make more informed investment decisions and potentially
                  increase their returns.
                </p>
              </div>
            </div>

            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>5. NAVYA Top 30</p>
                <p class='mt-1 text-gray-600 text-500'>
                  As we aspire to reshape the industry, we have come up with
                  industry leading stocks ranking - NAVYA Top 30. Top thirty
                  stocks that have shown strong upward momentum adjusted for
                  volatility based on past 90 days of price movements. The list
                  would be the perfect answer to the traders / investors
                  searching for the stocks that have high probability of
                  trending upwards.
                </p>
              </div>
            </div>

            <div class='bg-white'>
              <div class='py-8 px-9'>
                <p class='text-lg font-bold text-black'>6. Stock Market Q&A</p>
                <p class='mt-1 text-gray-600 text-500'>
                  The stock market Q&A feature offers users resources and
                  information to make informed investment choices. It provides
                  information covering stock market basics, portfolio
                  management, technical analysis, macroeconomics, and investment
                  strategies. With the stock market Q&A feature, users can
                  enhance their financial literacy and deepen their
                  understanding of the stock market, improving their chances of
                  successful investing.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
