// import heroimg from "../images/hero.png";
import { useTheme } from "@emotion/react";
import { Box } from "@mui/material";
import React from "react";

const Hero = () => {
  const theme = useTheme();
  return (
    <>
      <Box
        className=' h-[100vh] max-h-3xl items-center'
        sx={{
          color: theme.palette.primary.main,
          // backgroundColor: theme.palette.primary.main,
        }}
      >
        <div class='grid max-w-screen-xl px-4 pt-20 pb-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12 lg:pt-28'>
          <div class='mr-auto place-self-center lg:col-span-7'>
            <div class=' h-20'></div>
            <h1 class=' max-w-2xl mb-4 text-4xl font-extrabold  p-2 leading-none tracking-tight md:text-5xl xl:text-6xl '>
              Better Intelligence
            </h1>
            <hr className=' p-2'></hr>
            <p class='max-w-2xl mb-6 font-light  lg:mb-8 md:text-lg lg:text-xl '>
              With our AI Powered market intelligence tools you can now access
              to the credible market intelligence anytime at your finger tips.
              You don’t need to be an insider anymore.
            </p>
            <div class='space-y-4 sm:flex sm:space-y-0 sm:space-x-4'>
              {/* <a
                href="https://github.com/themesberg/landwind"
                class="inline-flex items-center justify-center w-full px-5 py-3 text-sm font-medium text-center text-gray-900 border border-gray-200 rounded-lg sm:w-auto hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark: dark:border-gray-700 dark:hover:bg-gray-700 dark:focus:ring-gray-800"
              >
                xvc
              </a> */}
              <a
                href='#'
                class='inline-flex items-center justify-center w-full px-5 py-3 mb-2 mr-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg sm:w-auto focus:outline-none hover:bg-green-700 hover: focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover: dark:hover:bg-gray-700'
              >
                Get Started
              </a>
            </div>
          </div>
          <div class=' lg:mt-0 lg:col-span-5 lg:flex'>
            {/* <img src={heroimg} alt='hero' /> */}
          </div>
        </div>
      </Box>
    </>
  );
};

export default Hero;

// color

// box-shadow: 10px 2px 80px 2px rgba(35,56,118,0.26);
// -webkit-box-shadow: 10px 2px 80px 2px rgba(35,56,118,0.26);
// -moz-box-shadow: 10px 2px 80px 2px rgba(35,56,118,0.26);
