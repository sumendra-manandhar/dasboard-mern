//  import React, { useState } from "react";
//  import {
//  	LightModeOutlined,
//  	DarkModeOutlined,
//  	Menu as MenuIcon,
//  	Search,
//  	SettingsOutlined,
//  	ArrowDropDownOutlined,
//  } from "@mui/icons-material";
//  import FlexBetween from "components/FlexBetween";
//  import { useDispatch } from "react-redux";
//  import { setMode } from "state";
//  import profileImage from "assets/profile.png";
//  import {
// 	AppBar,
// 	Button,
// 	Box,
// 	Typography,
// 	IconButton,
// 	InputBase,
// 	Toolbar,
// 	Menu,
// 	MenuItem,
// 	useTheme,
// } from "@mui/material";

// const Navbar = ({ isSidebarOpen, setIsSidebarOpen }) => {
// 	const dispatch = useDispatch();
// 	const theme = useTheme();

// 	const [anchorEl, setAnchorEl] = useState(null);
// 	const isOpen = Boolean(anchorEl);
// 	const handleClick = (event) => setAnchorEl(event.currentTarget);
// 	const handleClose = () => setAnchorEl(null);

// 	return (
// 		<AppBar
// 			sx={{
// 				position: "static",
// 				background: "none",
// 				boxShadow: "none",
// 			}}
// 		>
// 			<Toolbar sx={{ justifyContent: "space-between" }}>
// 				{/* LEFT SIDE */}
// 				<FlexBetween>
// 					<IconButton onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
// 						<MenuIcon />
// 					</IconButton>
// 					<FlexBetween
// 						backgroundColor={theme.palette.background.alt}
// 						borderRadius='9px'
// 						gap='3rem'
// 						p='0.1rem 1.5rem'
// 					>
// 						<InputBase placeholder='Search...' />
// 						<IconButton>
// 							<Search />
// 						</IconButton>
// 					</FlexBetween>
// 				</FlexBetween>

// 				{/* RIGHT SIDE */}
// 				<FlexBetween gap='1.5rem'>
// 					<IconButton onClick={() => dispatch(setMode())}>
// 						{theme.palette.mode === "dark" ? (
// 							<DarkModeOutlined sx={{ fontSize: "25px" }} />
// 						) : (
// 							<LightModeOutlined sx={{ fontSize: "25px" }} />
// 						)}
// 					</IconButton>
// 					<IconButton>
// 						<SettingsOutlined sx={{ fontSize: "25px" }} />
// 					</IconButton>

// 					<FlexBetween>
// 						<Button
// 							onClick={handleClick}
// 							sx={{
// 								display: "flex",
// 								justifyContent: "space-between",
// 								alignItems: "center",
// 								textTransform: "none",
// 								gap: "1rem",
// 							}}
// 						>
// 							<Box
// 								component='img'
// 								alt='profile'
// 								src={profileImage}
// 								height='32px'
// 								width='32px'
// 								borderRadius='50%'
// 								sx={{ objectFit: "cover" }}
// 							/>
// 							<Box textAlign='left'>
// 								<Typography
// 									fontWeight='bold'
// 									fontSize='0.85rem'
// 									sx={{ color: theme.palette.primary[100] }}
// 								>
// 									{/* {user.name} */}
// 									UserName
// 								</Typography>
// 								<Typography
// 									fontSize='0.75rem'
// 									sx={{ color: theme.palette.secondary[200] }}
// 								>
// 									{/* {user.occupation} */}
// 									Role
// 								</Typography>
// 							</Box>
// 							<ArrowDropDownOutlined
// 								sx={{ color: theme.palette.secondary[300], fontSize: "25px" }}
// 							/>
// 						</Button>
// 						<Menu
// 							anchorEl={anchorEl}
// 							open={isOpen}
// 							onClose={handleClose}
// 							anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
// 						>
// 							<MenuItem onClick={handleClose}>Log Out</MenuItem>
// 						</Menu>
// 					</FlexBetween>
// 				</FlexBetween>
// 			</Toolbar>
// 		</AppBar>
// 	);
// };

// export default Navbar;

import React, { useEffect, useState } from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import { useDispatch } from "react-redux";
import { useTheme } from "@mui/system";
import FlexBetween from "./FlexBetween";
import { setMode } from "state";
import {
  ChevronRightOutlined,
  DarkModeOutlined,
  HomeOutlined,
  LightModeOutlined,
} from "@mui/icons-material";
import {
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Slide,
  useScrollTrigger,
} from "@mui/material";

import PropTypes from "prop-types";
import { useLocation, useNavigate } from "react-router-dom";

const pages = ["Products", "Pricing", "Blog"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];

const navItems = [
  {
    text: "Home",
    icon: <HomeOutlined />,
  },
  {
    text: "Fund Transfer",
    icon: null,
  },

  {
    text: "About Us",
    icon: <HomeOutlined />,
  },
  {
    text: "Services",
    icon: <HomeOutlined />,
  },

  {
    text: "Education",
    icon: <HomeOutlined />,
  },
  {
    text: "Contact",
    icon: <HomeOutlined />,
  },
];

// Navbar Hide on Scroll -------------

function HideOnScroll(props) {
  const { children, window } = props;
  // Note that you normally won't need to set the window ref as useScrollTrigger
  // will default to window.
  // This is only being set here because the demo is in an iframe.
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
  });

  return (
    <Slide appear={false} direction='down' in={!trigger}>
      {children}
    </Slide>
  );
}

HideOnScroll.propTypes = {
  children: PropTypes.element.isRequired,
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

// Navbar Hide on Scroll --------------------

function Navbar(props) {
  const { pathname } = useLocation();
  const [active, setActive] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    setActive(pathname.substring(1));
  }, [pathname]);

  const dispatch = useDispatch();
  const theme = useTheme();

  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <HideOnScroll {...props}>
      <AppBar>
        {/* <Container maxWidth='xl'>
          <Toolbar disableGutters>
            <AdbIcon sx={{ display: { xs: "none", md: "flex" }, mr: 1 }} />
            <Typography
              variant='h6'
              noWrap
              component='a'
              href='/'
              sx={{
                mr: 2,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              LOGO
            </Typography>

            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size='large'
                aria-label='account of current user'
                aria-controls='menu-appbar'
                aria-haspopup='true'
                onClick={handleOpenNavMenu}
                color='inherit'
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id='menu-appbar'
                anchorEl={anchorElNav}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                open={Boolean(anchorElNav)}
                onClose={handleCloseNavMenu}
                sx={{
                  display: { xs: "block", md: "none" },
                }}
              >
                {pages.map((page) => (
                  <MenuItem key={page} onClick={handleCloseNavMenu}>
                    <Typography textAlign='center'>{page}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
            <AdbIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 }} />
            <Typography
              variant='h5'
              noWrap
              component='a'
              href=''
              sx={{
                mr: 2,
                display: { xs: "flex", md: "none" },
                flexGrow: 1,
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              LOGO
            </Typography>
            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
              {pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleCloseNavMenu}
                  sx={{ my: 2, color: "white", display: "block" }}
                >
                  {page}
                </Button>
              ))}
            </Box>

            <FlexBetween gap='1.5rem'>
              <IconButton onClick={() => dispatch(setMode())}>
                {theme.palette.mode === "dark" ? (
                  <DarkModeOutlined sx={{ fontSize: "25px" }} />
                ) : (
                  <LightModeOutlined sx={{ fontSize: "25px" }} />
                )}
              </IconButton>
            </FlexBetween>

            <Box sx={{ flexGrow: 0 }}>
              <Tooltip title='Open settings'>
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar alt='Remy Sharp' src='/static/images/avatar/2.jpg' />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: "45px" }}
                id='menu-appbar'
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting} onClick={handleCloseUserMenu}>
                    <Typography textAlign='center'>{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Toolbar>
        </Container> */}

        <header class='bg-blue-700 fixed w-full'>
          <nav class='  border-gray-200 py-2.5 dark:bg-gray-900'>
            <div class='flex flex-wrap items-center justify-between max-w-screen-xl px-4 mx-auto'>
              <div>{/* <img src={logo} alt="logo" width="120px"></img> */}</div>
              <span class='  self-center text-xl font-semibold whitespace-nowrap dark:text-white'>
                NAVYA ADVISORS
              </span>

              <div class='flex items-center lg:order-2'>
                <a
                  href='#'
                  class=' hover:bg-gray-50 hover:text-black focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 sm:mr-2 dark:hover:bg-gray-700 focus:outline-none dark:focus:ring-gray-800'
                >
                  Log in
                </a>
                <a
                  href=''
                  class='text-white bg-green-700 hover:bg-white hover:text-black focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 sm:mr-2 lg:mr-0 dark:bg-purple-600 dark:hover:bg-purple-700 focus:outline-none dark:focus:ring-purple-800'
                >
                  Get Started
                </a>
                <FlexBetween gap='1.5rem'>
                  <IconButton onClick={() => dispatch(setMode())}>
                    {theme.palette.mode === "dark" ? (
                      <DarkModeOutlined sx={{ fontSize: "25px" }} />
                    ) : (
                      <LightModeOutlined sx={{ fontSize: "25px" }} />
                    )}
                  </IconButton>
                </FlexBetween>
                <button
                  data-collapse-toggle='mobile-menu-2'
                  type='button'
                  class='inline-flex items-center p-2 ml-1 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600'
                  aria-controls='mobile-menu-2'
                  aria-expanded='false'
                >
                  <span class='sr-only'>Open main menu</span>
                  <svg
                    class='w-6 h-6'
                    fill='currentColor'
                    viewBox='0 0 20 20'
                    xmlns='http://www.w3.org/2000/svg'
                  >
                    <path
                      fill-rule='evenodd'
                      d='M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z'
                      clip-rule='evenodd'
                    ></path>
                  </svg>
                  <svg
                    class='hidden w-6 h-6'
                    fill='currentColor'
                    viewBox='0 0 20 20'
                    xmlns='http://www.w3.org/2000/svg'
                  >
                    <path
                      fill-rule='evenodd'
                      d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z'
                      clip-rule='evenodd'
                    ></path>
                  </svg>
                </button>
              </div>
              <div
                class='items-center justify-between hidden w-full lg:flex lg:w-auto lg:order-1'
                id='mobile-menu-2'
              >
                <ul class='flex flex-col mt-4 font-medium lg:flex-row lg:space-x-8 lg:mt-0'>
                  <li>
                    <a
                      href='#'
                      class='block py-2 pl-3 pr-4  lg:p-0 dark:text-white hover:underline  hover:border-spacing-y-2'
                      aria-current='page'
                    >
                      About Us
                    </a>
                  </li>
                  <li>
                    <a
                      href='#'
                      class='block py-2 pl-3 pr-4  border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-white lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700'
                    >
                      Services
                    </a>
                  </li>
                  <li>
                    <a
                      // herf={NewsFeed}
                      class='block py-2 pl-3 pr-4 text-white border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-white lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700'
                    >
                      News Feed
                    </a>
                  </li>
                  <li>
                    <a
                      href='./www.google.com'
                      class='block py-2 pl-3 pr-4 text-white border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-white lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700'
                    >
                      Education
                    </a>
                  </li>
                  <li>
                    <a
                      href='#'
                      class='block py-2 pl-3 pr-4 text-white border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-white lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700'
                    >
                      Contact
                    </a>
                  </li>
                  <li>
                    <a
                      href='#'
                      class=' relative block py-2 pl-3 pr-4 text-white border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-white lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700'
                    >
                      Work With Us
                      <div class='inline-flex absolute  ml-1 -right-15 justify-center items-center px-3  text-xs  text-white bg-red-500 rounded-full  dark:border-gray-900'>
                        New
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </header>
      </AppBar>
    </HideOnScroll>
  );
}
export default Navbar;
